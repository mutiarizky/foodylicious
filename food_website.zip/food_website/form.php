
<?php
If (isset($_GET['simpan']))
{
	$nama=$_GET['nama'];
	echo Nama Anda : <b>$nama</b>;
}
?>